Nico Schlömer designed and implemented the intial version and is the current maintainer.

Thanks for patches, suggestions, and other contributions go to:

  * Martijn Aben (The MathWorks)
  * Ben Abbott
  * Eike Blechschmidt
  * Klaus Broelemann
  * Katherine Elkington
  * Andreas Gäb
  * Egon Geerardyn
  * Roman Gesenhues
  * Michael Glasser (The MathWorks)
  * David Haberthür
  * Patrick Häcker
  * David Horsley
  * Burkart Lingner
  * Oleg Komarov
  * Mykel Kochenderfer
  * Henk Kortier
  * Theo Markettos
  * Dragan Mitrevski
  * Francesco Montorsi
  * Peter Pablo
  * Ricardo Santiago Mozos
  * Johannes Mueller-Roemer
  * Julien Ridoux
  * Christoph Rüdiger
  * Carlos Russo
  * Johannes Schmitz
  * Michael Schoeberl
  * Donghua Wang
  * Robert Whittlesey
  * Pooya Ziraksaz
  * Bastiaan Zuurendonk (The MathWorks)
  * _and many more!_

Matlab2tikz has once greatly profited from its ancestor:

  * [Matfig2PGF](http://www.mathworks.com/matlabcentral/fileexchange/12962) written by Paul Wagenaars.

Also, the authors would like to thank Christian Feuersänger for the [Pgfplots](http://pgfplots.sourceforge.net) package which forms the basis for the matlab2tikz output on the LaTeX side.
